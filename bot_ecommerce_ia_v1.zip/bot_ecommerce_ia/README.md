# Bot E-commerce IA — CJdropshipping + Shopify (MVP)

## Ce que fait cette version
- Analyse un CSV de produits
- Calcule un prix de vente indicatif et une marge estimée
- Attribue un score heuristique /100
- Génère une base de fiche produit et une accroche marketing
- Exporte les résultats en CSV / TXT
- N'achète rien, ne publie rien et ne lance aucune publicité

## Important
Cette V1 ne se connecte pas encore automatiquement à CJdropshipping ou Shopify. Les intégrations directes nécessitent des clés API et un environnement hébergé sécurisé. Ne mettez jamais vos clés dans un fichier public ou dans un chat.

Les données d'exemple sont fictives et ne représentent pas des offres réelles. Le score n'est pas une prévision de ventes.

## Lancer sur un ordinateur (si disponible plus tard)
1. Installer Python 3.10+
2. Ouvrir un terminal dans ce dossier
3. `pip install -r requirements.txt`
4. `streamlit run app.py`

## Utilisation depuis un téléphone
Le fichier fourni est le code source, pas une application déjà hébergée. Pour l'utiliser depuis un téléphone, il faut le déployer sur un service compatible (par exemple Streamlit Community Cloud) via un dépôt GitHub. Cela demande une configuration initiale; les offres et limites des services peuvent changer.

## CSV accepté
Colonnes obligatoires:
- `product_name`
- `product_cost_eur`
- `shipping_eur`

Colonnes facultatives:
- `competitor_price_eur`
- `shipping_days`
- `rating_1_5`
- `video_demo` (1 à 5)
- `fragility_1_5` (1 à 5)
- `regulatory_risk_1_5` (1 à 5)
- `stock_available`
- `product_url`

## Étape suivante pour les intégrations
- CJdropshipping API: consulter la documentation officielle et obtenir des identifiants depuis le compte CJ.
- Shopify: utiliser une application avec le minimum d'autorisations nécessaires, notamment `write_products` si création de produits souhaitée.
- Déployer le backend avec secrets protégés côté serveur.
- Garder la publication en brouillon et demander une validation humaine avant publication.
