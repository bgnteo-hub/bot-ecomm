import streamlit as st
import pandas as pd
from pathlib import Path
from html import escape

st.set_page_config(page_title="Bot E-commerce IA", page_icon="🛍️", layout="wide")
st.title("🛍️ Bot E-commerce IA — CJdropshipping + Shopify")
st.caption("MVP de sélection de produits • estimation de marge • fiches marketing • validation manuelle")

with st.sidebar:
    st.header("Paramètres")
    target_market = st.selectbox("Marché cible", ["France", "Union européenne", "International"])
    min_margin = st.number_input("Marge minimale estimée (€)", min_value=0.0, value=10.0, step=1.0)
    margin_rate = st.number_input("Frais de paiement estimés (%)", min_value=0.0, max_value=20.0, value=2.5, step=0.5)
    extra_cost = st.number_input("Autres coûts par commande (€)", min_value=0.0, value=1.0, step=0.5)
    desired_markup = st.number_input("Coefficient prix conseillé", min_value=1.0, max_value=8.0, value=2.5, step=0.1)

st.info("Cette version fonctionne sans clé API et sans frais. Elle n'invente pas les données de CJ : importe un CSV de produits ou utilise les exemples. La connexion directe à CJ/Shopify nécessite des accès API et un hébergement sécurisé.")

sample = pd.DataFrame([
    {"product_name":"Brosse anti-poils réutilisable","product_cost_eur":4.0,"shipping_eur":4.0,"competitor_price_eur":24.90,"shipping_days":8,"rating_1_5":4.4,"video_demo":5,"fragility_1_5":1,"regulatory_risk_1_5":1,"stock_available":"Oui","product_url":"https://www.cjdropshipping.com/"},
    {"product_name":"Support téléphone voiture","product_cost_eur":3.5,"shipping_eur":3.8,"competitor_price_eur":19.90,"shipping_days":7,"rating_1_5":4.2,"video_demo":4,"fragility_1_5":1,"regulatory_risk_1_5":1,"stock_available":"À vérifier","product_url":"https://www.cjdropshipping.com/"},
    {"product_name":"Diffuseur LED décoratif","product_cost_eur":8.0,"shipping_eur":5.0,"competitor_price_eur":34.90,"shipping_days":9,"rating_1_5":4.0,"video_demo":5,"fragility_1_5":3,"regulatory_risk_1_5":3,"stock_available":"À vérifier","product_url":"https://www.cjdropshipping.com/"},
])

uploaded = st.file_uploader("Importer un CSV de produits CJ (facultatif)", type=["csv"])
if uploaded:
    try:
        products = pd.read_csv(uploaded)
    except Exception as e:
        st.error(f"CSV illisible : {e}")
        st.stop()
else:
    products = sample.copy()
    st.caption("Exemples fictifs pour tester l'application — ce ne sont pas des offres vérifiées.")

required = ["product_name","product_cost_eur","shipping_eur"]
missing = [c for c in required if c not in products.columns]
if missing:
    st.error("Colonnes obligatoires manquantes : " + ", ".join(missing))
    st.stop()

defaults = {
    "competitor_price_eur": 0, "shipping_days": 10, "rating_1_5": 3.5,
    "video_demo": 3, "fragility_1_5": 2, "regulatory_risk_1_5": 1,
    "stock_available": "À vérifier", "product_url": ""
}
for col, default in defaults.items():
    if col not in products.columns:
        products[col] = default

def score_row(r):
    # Heuristic score only, not a sales forecast.
    price = float(r.get("competitor_price_eur", 0) or 0)
    cost = float(r.get("product_cost_eur", 0) or 0) + float(r.get("shipping_eur", 0) or 0)
    profit = price - cost - price * margin_rate / 100 - extra_cost
    margin_component = max(0, min(40, (profit / max(price, 1)) * 100 * 0.8))
    video_component = max(0, min(20, float(r.get("video_demo", 3) or 3) * 4))
    rating_component = max(0, min(15, float(r.get("rating_1_5", 3.5) or 3.5) * 3))
    delivery_component = max(0, min(10, 10 - max(0, float(r.get("shipping_days", 10) or 10) - 3) * 0.8))
    fragility_penalty = max(0, min(8, (float(r.get("fragility_1_5", 2) or 2) - 1) * 2))
    risk_penalty = max(0, min(15, (float(r.get("regulatory_risk_1_5", 1) or 1) - 1) * 4))
    stock_bonus = 5 if str(r.get("stock_available", "")).lower() in ["oui","yes","available","en stock"] else 0
    return round(max(0, min(100, margin_component + video_component + rating_component + delivery_component + stock_bonus - fragility_penalty - risk_penalty)), 1)

products["product_cost_eur"] = pd.to_numeric(products["product_cost_eur"], errors="coerce").fillna(0)
products["shipping_eur"] = pd.to_numeric(products["shipping_eur"], errors="coerce").fillna(0)
products["suggested_price_eur"] = ((products["product_cost_eur"] + products["shipping_eur"]) * desired_markup).round(2)
# Avoid a suggested price below competitor price where competitor price is known; still a hypothesis.
products["suggested_price_eur"] = products.apply(lambda r: max(r["suggested_price_eur"], float(r["competitor_price_eur"] or 0) if pd.notna(r["competitor_price_eur"]) else 0), axis=1)
products["payment_fee_eur"] = (products["suggested_price_eur"] * margin_rate / 100).round(2)
products["estimated_profit_eur"] = (products["suggested_price_eur"] - products["product_cost_eur"] - products["shipping_eur"] - products["payment_fee_eur"] - extra_cost).round(2)
products["score_100"] = products.apply(score_row, axis=1)
products["recommendation"] = products.apply(lambda r: "À étudier" if r["estimated_profit_eur"] >= min_margin and r["score_100"] >= 65 else "Ne pas prioriser", axis=1)
products = products.sort_values(["score_100","estimated_profit_eur"], ascending=False)

c1,c2,c3 = st.columns(3)
c1.metric("Produits analysés", len(products))
c2.metric("Produits à étudier", int((products["recommendation"]=="À étudier").sum()))
c3.metric("Marge estimée moyenne", f'{products["estimated_profit_eur"].mean():.2f} €' if len(products) else "—")

st.subheader("Classement des produits")
cols = ["product_name","score_100","product_cost_eur","shipping_eur","suggested_price_eur","estimated_profit_eur","recommendation","stock_available"]
st.dataframe(products[[c for c in cols if c in products.columns]], use_container_width=True, hide_index=True)
st.download_button("Télécharger le classement CSV", products.to_csv(index=False).encode("utf-8-sig"), "classement_produits.csv", "text/csv")

st.divider()
st.subheader("Générateur de fiche produit")
chosen = st.selectbox("Choisir un produit", products["product_name"].astype(str).tolist())
row = products[products["product_name"].astype(str)==chosen].iloc[0]
title = f"{chosen} | Solution pratique au quotidien"
description = f"""
<p><strong>Découvrez {escape(chosen.lower())}</strong>, un accessoire pensé pour simplifier votre quotidien.</p>
<ul>
<li>Utilisation simple et pratique</li>
<li>Conçu pour un usage quotidien</li>
<li>Consultez les caractéristiques exactes et les consignes du fournisseur avant publication</li>
</ul>
<p><em>Vérifiez les matériaux, dimensions, compatibilités, délais de livraison et conditions de retour avant de mettre cette fiche en ligne.</em></p>
"""
ad = f"Vous cherchez une solution pratique pour le quotidien ? Découvrez {chosen}. Regardez la démonstration, vérifiez les détails du produit et voyez s'il vous convient."
st.text_input("Titre proposé", value=title, key="title")
st.text_area("Description HTML proposée", value=description, height=180, key="desc")
st.text_area("Accroche vidéo / publicité", value=ad, height=100, key="ad")
st.download_button("Télécharger la fiche texte", f"TITRE\n{title}\n\nDESCRIPTION HTML\n{description}\n\nACCROCHE\n{ad}", "fiche_produit.txt", "text/plain")

st.warning("Avant toute publication : confirmez le coût et le stock en direct, les frais/délais de livraison vers le pays cible, les droits d'utilisation des images, la conformité UE et les obligations de vendeur. Les scores sont heuristiques et ne prédisent pas les ventes.")
st.caption("MVP local : aucune commande n'est passée, aucun produit n'est publié et aucune publicité n'est lancée.")
